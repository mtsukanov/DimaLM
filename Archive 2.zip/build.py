#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build.py — пересборка index.html из исходников.

Использование:
    python3 build.py            — пересобрать всё
    python3 build.py --prompt   — пересобрать только SYSTEM_PROMPT
    python3 build.py --replies  — пересобрать только DI_REPLIES
    python3 build.py --assets   — пересобрать только ASSETS

Источники:
    system_prompt.md     — текст системного промпта для LLM
    replies_mapping.md   — таблица фирменных фраз Димы
    avatars/avatar_*.jpeg — изображения для встраивания в Base64

В index.html должны быть маркеры (расставлены автоматически при первой
сборке): /* ASSETS_BEGIN */ ... /* ASSETS_END */, аналогично для
DI_REPLIES и SYSTEM_PROMPT.
"""

import sys
import re
import json
import base64
import pathlib
import argparse

ROOT = pathlib.Path(__file__).parent.resolve()

INDEX_PATH       = ROOT / "index.html"
PROMPT_PATH      = ROOT / "system_prompt.md"
REPLIES_PATH     = ROOT / "replies_mapping.md"
AVATARS_DIR      = ROOT / "avatars"


def fail(msg: str) -> None:
    print(f"[build] ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def patch_block(html: str, marker: str, new_body: str) -> str:
    """Заменить содержимое блока между /* {marker}_BEGIN ... */ и /* {marker}_END */."""
    pattern = re.compile(
        r"(/\*\s*" + re.escape(marker) + r"_BEGIN[^*]*\*/\s*\n)"
        r"([\s\S]*?)"
        r"(\n\s*/\*\s*" + re.escape(marker) + r"_END\s*\*/)",
        re.MULTILINE,
    )
    if not pattern.search(html):
        fail(f"маркер {marker}_BEGIN/{marker}_END не найден в index.html")
    return pattern.sub(lambda m: m.group(1) + new_body + m.group(3), html, count=1)


# ----------------------------- builders --------------------------------

def build_system_prompt() -> str:
    if not PROMPT_PATH.exists():
        fail(f"не найден {PROMPT_PATH}")
    text = PROMPT_PATH.read_text(encoding="utf-8")
    # JSON-encode → безопасная JS-строка с \n, кавычками, юникодом
    js_string = json.dumps(text, ensure_ascii=False)
    return f"const SYSTEM_PROMPT = {js_string};"


def build_di_replies() -> str:
    if not REPLIES_PATH.exists():
        fail(f"не найден {REPLIES_PATH}")
    lines = REPLIES_PATH.read_text(encoding="utf-8").splitlines()
    replies = []
    for line in lines:
        line = line.strip()
        if not line.startswith("|"):
            continue
        if "Line #" in line or set(line.replace("|", "").replace(":", "").strip()) <= {"-", " "}:
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 4:
            continue
        try:
            idx = int(cells[0])
        except ValueError:
            continue
        text = cells[1]
        m = re.search(r"avatar_\d+\.jpeg", cells[2])
        avatar = m.group(0) if m else "avatar_2.jpeg"
        emotion = re.sub(r"<[^>]+>", "", cells[3])
        emotion = re.sub(r"^В+нимательный$", "Внимательный", emotion)
        replies.append({"id": idx, "text": text, "avatar": avatar, "emotion": emotion})
    if not replies:
        fail("в replies_mapping.md не нашлось ни одной строки таблицы")
    body = "const DI_REPLIES = " + json.dumps(replies, ensure_ascii=False, indent=2) + ";"
    return body


def build_assets() -> str:
    if not AVATARS_DIR.exists():
        fail(f"не найден каталог {AVATARS_DIR}")
    parts = ["const ASSETS = {"]
    found = sorted(AVATARS_DIR.glob("avatar_*.jpeg"),
                   key=lambda p: int(re.search(r"\d+", p.stem).group(0)))
    if not found:
        fail("в avatars/ нет файлов avatar_*.jpeg")
    for p in found:
        b64 = base64.b64encode(p.read_bytes()).decode("ascii")
        parts.append(f'  "{p.name}": "data:image/jpeg;base64,{b64}",')
    parts.append("};")
    return "\n".join(parts)


# ----------------------------- main ------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Пересборка index.html")
    parser.add_argument("--prompt",  action="store_true", help="только SYSTEM_PROMPT")
    parser.add_argument("--replies", action="store_true", help="только DI_REPLIES")
    parser.add_argument("--assets",  action="store_true", help="только ASSETS")
    args = parser.parse_args()

    do_all = not (args.prompt or args.replies or args.assets)

    if not INDEX_PATH.exists():
        fail(f"не найден {INDEX_PATH}")

    html = INDEX_PATH.read_text(encoding="utf-8")
    changed = []

    if do_all or args.prompt:
        html = patch_block(html, "SYSTEM_PROMPT", build_system_prompt())
        changed.append("SYSTEM_PROMPT")
    if do_all or args.replies:
        html = patch_block(html, "DI_REPLIES", build_di_replies())
        changed.append("DI_REPLIES")
    if do_all or args.assets:
        html = patch_block(html, "ASSETS", build_assets())
        changed.append("ASSETS")

    INDEX_PATH.write_text(html, encoding="utf-8")
    size_kb = INDEX_PATH.stat().st_size / 1024
    print(f"[build] обновлены блоки: {', '.join(changed)}")
    print(f"[build] index.html → {size_kb:.1f} КБ")


if __name__ == "__main__":
    main()
